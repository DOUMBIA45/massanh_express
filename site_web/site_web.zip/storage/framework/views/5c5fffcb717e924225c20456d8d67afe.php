<?php $__env->startSection('title'); ?>
    Création de site internet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs " style="height: 100px">
        <div class="breadcrumbs breadcrumb-hero">
            <ol>
                <li><a href="/" style="font-size:25px"><b>Home</b></a></li>
                <li style="font-size:25px"><b>Creation d'applicaation web mobile </b></li>
            </ol>
        </div>
    </section><!-- End Breadcrumbs -->
    <br><br>
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 pt-3 pt-lg-0 content">
                    <p>Votre site web est la vitrine de votre structure, sa conception est cruciale pour la pérennité de votre image de marque.</p>
                    <p>Chez MaconseillèreCom, nous mesurons l’importance de cette étape et nous nous engageons à toujours être à l’écoute de vos besoins et objectifs.</p>
                    <p>Notre équipe d’ingénieurs conçoit aussi des applications mobiles en adéquation avec votre stratégie de communication.</p>
                </div>

            </div>
            <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary" style='float:right;background-color:#44b6e3;border: 1px solid ;background-color:#44b6e3;'><b>Contactez-nous</b></a>
        </div>
    </section><!-- End About Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projets\maconseillerecom\resources\views/marketing_digital/creation_site_internet.blade.php ENDPATH**/ ?>