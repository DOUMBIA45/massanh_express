<?php $__env->startSection('title'); ?>
    Stratégie digitale
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs p-2" style="height: 90px">
        <div class="breadcrumbs breadcrumb-hero">
            <ol>
                <li><a href="/" style="font-size:25px"><b>Home</b></a></li>
                <li style="font-size:25px"><b>Strategie digitale</b></li>
            </ol>
        </div>
    </section><!-- End Breadcrumbs -->
    <br><br>
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 pt-3 pt-lg-0 content">
                    <p>Écrire sur internet est devenu une nouvelle forme d’art. Un de ceux qui exigent une jolie prose pour séduire les utilisateurs mais aussi qui soit hautement mathématique et efficace pour les robots. Votre référencement dépend de la maîtrise de ces deux aspects.</p>
                    <p>Si votre cible utilise les réseaux sociaux, alors qu’attendez-vous ?</p>
                    <ul>
                        <li> Quels réseaux ? </li>
                        <li> Quelle personnalité ?</li>
                        <li> Quel rythme ? </li>
                        <li> Quelle modération ? </li>
                        <li> L’objectif de MaconseillereCOM est de vous préparer tous les ingrédients clés pour être autonomes et aimés. ? </li>
                    </ul>
                </div>

            </div>
            <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary" style='float:right;background-color:#44b6e3;border: 1px solid ;background-color:#44b6e3;'><b>Contactez-nous</b></a>
        </div>
    </section><!-- End About Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projets\maconseillerecom\resources\views/marketing_digital/strategie_digitale.blade.php ENDPATH**/ ?>