@extends('admin.template')

@section('title_admin')
    Admin/dashboard
@endsection

@section('admin_content')

@endsection
