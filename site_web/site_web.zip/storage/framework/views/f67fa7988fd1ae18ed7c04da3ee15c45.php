<div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <h4>MaconseillèreCom</h4>
            <p> Agence de communication  spécialisée en stratégie de la communication , les relations publiques et la gestion de Crises.</p><br> 
            <p> Une Agence pour vous. <br> Une agence plus proche de vous.</p> 
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Lien utils</h4>
            <ul>
              <li><a href="/">Accueil</a></li>
              <li><a href="#">Agence conseil</a></li>
              <li><a href="#">Communication</a></li>
              <li><a href="#">Relations publiques</a></li>
              <li><a href="#">Marketing Dgital</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact</h4>
            <p>
              Abidjan, Côte d'Ivoire <br>
              Ouaga, Burkina Faso<br>
              <strong>Phone:</strong> +225 05 86 28 55 00 <br>
              <strong>Phone:</strong> +226 05 55 50 05<br>
              <strong>Email:</strong> contact@maconseillerecom.com<br>
              <strong>Email:</strong>direction@maconseillerecom.com
            
            </p>

            <div class="social-links">
              <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
              <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
              <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
            </div>

          </div>

          <div class="col-lg-3 col-md-6 footer-newsletter">
            <h4>Newsletter</h4>
            <p>Abonnez-vous à la newsletter de Culturez-vous pour ne rien louper de notre actualité !</p><br><br>
            <form action="#">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div><?php /**PATH E:\projets\maconseillerecom\resources\views/layout/footer.blade.php ENDPATH**/ ?>