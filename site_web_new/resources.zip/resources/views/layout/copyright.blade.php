<div class="container">
    <div class="row g-4 align-items-center">
        <div class="col-md-6 text-center text-md-end mb-md-0">
            <i class="fas fa-copyright me-2"></i><a class="text-white" href="/">Massanh Express</a>, All right reserved.
        </div>
        <div class="col-md-6 text-center text-md-start">
            <!--/*** This template is free as long as you keep the below author’s credit link/attribution link/backlink. ***/-->
            <!--/*** If you'd like to use the template without the below author’s credit link/attribution link/backlink, ***/-->
            <!--/*** you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". ***/-->
            Designed By <a class="text-white" href="https://htmlcodex.com">HTML Codex</a> Distributed By <a href="https://themewagon.com">ThemeWagon</a>
        </div>
    </div>
</div>
