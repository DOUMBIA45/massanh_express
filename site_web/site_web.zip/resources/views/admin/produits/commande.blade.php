@extends('admin.template')

@section('title_admin')
    Admin/services
@endsection

@section('admin_content')

@endsection
