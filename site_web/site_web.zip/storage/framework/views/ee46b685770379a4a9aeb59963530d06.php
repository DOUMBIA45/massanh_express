<?php $__env->startSection('title'); ?>
    Communication visuelle
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs p-2" style="height: 100px">
        <div class="breadcrumbs breadcrumb-hero">
            <ol>
                <li><a href="/" style="font-size:25px"><b>Home</b></a></li>
                <li style="font-size:25px"><b>Communication visuelle</b></li>
            </ol>
        </div>
    </section><!-- End Breadcrumbs -->
    <br><br>
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 pt-3 pt-lg-0 content Moi">
                    <p>De la conception à la matérialisation de votre maquette, passant par le renouvellement de votre logos… Nos experts travaillent avec affinement et délicatesse jusqu’à l’impression de qualité du produit fini.</p>

                    <h4 style="font-size: 20px"><b>ACTIVITES :</b> </h4>
                    <ul>
                        <li> Infographie</li>
                        <li> Designer</li>
                        <li>Identité visuelle</li>
                        <li> Shooting Professionnel ciblé </li>
                        <li> Impression numérique, impression offset </li>
                        <li> Sérigraphie & broderie</li>
                        <li> Affichage (PANNEAUX)</li>
                    </ul>
                </div>

            </div>
            <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary" style='float:right;background-color:#44b6e3;border: 1px solid ;background-color:#44b6e3;'><b>Contactez-nous</b></a>
        </div>
    </section><!-- End About Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projets\maconseillerecom\resources\views/communication/communication_visuelle.blade.php ENDPATH**/ ?>