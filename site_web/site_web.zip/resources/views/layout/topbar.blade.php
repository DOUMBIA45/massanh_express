<div class="row gx-0 align-items-center">
    <div class="col-lg-7 px-5 text-start">
        <div class="h-100 d-inline-flex align-items-center me-4">
            <small class="fa fa-phone-alt me-2"></small>
            <small class="text-white">(+225) 07 77 11 62 61</small>
        </div>
        <div class="h-100 d-inline-flex align-items-center me-4">
            <small class="far fa-envelope-open me-2"></small>
            <small class="text-white">office@massananhexpertiz.com / massananh1er@gmail.com</small>
        </div>
        <div class="h-100 d-inline-flex align-items-center me-4">
            <small class="far fa-clock me-2"></small>
            <small class="text-white">24h/24 7j/7</small>
        </div>
    </div>
    <div class="col-lg-5 px-5 text-end">
        <div class="h-100 d-inline-flex align-items-center">
            <a class="text-white-50 ms-4 text-white" href=""><i class="fab fa-facebook-f text-white"></i></a>
            <a class="text-white-50 ms-4 text-white" href=""><i class="fab fa-twitter text-white"></i></a>
            <a class="text-white-50 ms-4 text-white" href=""><i class="fab fa-linkedin-in text-white"></i></a>
            <a class="text-white-50 ms-4 text-white" href=""><i class="fab fa-instagram text-white  "></i></a>
        </div>
    </div>
</div>
