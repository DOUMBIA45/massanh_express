<?php $__env->startSection('title'); ?>
contact
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main id="main">
        <br>
        <!-- ======= Breadcrumbs ======= -->
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container">
               <br><br>

            </div>
        </section><!-- End Breadcrumbs -->
        <section class="inner-page">
            <div class="container">
                <!-- ======= Contact Section ======= -->
                <section id="contact" class="contact">
                    <div class="container" data-aos="fade-up">

                        <div class="section-title">
                            <h2>Contactez-nous</h2>

                        </div>
                        <?php if(Session::has('error')): ?>
                            <div class="row">
                                <div class="col-lg-3"></div>
                                <div class="col-lg-6">
                                    <div class="card">
                                        <div class="card-body text-center" style="background-color:red">
                                            <b  style="color:#ffffff"><?php echo e(Session::get('error')); ?></b>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3"></div>
                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('succes')): ?>
                            <div class="row">
                                <div class="col-lg-2"></div>
                                <div class="col-lg-8">
                                    <div class="card">
                                        <div class="card-body text-start" style="background-color:green">
                                            <b  style="color:#ffffff"><?php echo e(Session::get('succes')); ?></b><br>
                                            <b  style="color:#ffffff">votre message a bien été soumis, vous serez contactés dans un plus bref delais</b><br>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-2"></div>
                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
                                <form action="<?php echo e(route('setContact')); ?>" method="post" role="form" class="php-email-form">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="form-group col-md-6">
                                            <label for="name"><b>Nom</b></label>
                                            <input type="text" name="nom" class="form-control" id="nom" required>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="name"><b>Prénoms</b></label>
                                            <input type="text" class="form-control" name="prenoms" id="prenoms" required>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-6">
                                            <label for="name"><b>Email</b></label>
                                            <input type="email" name="email" class="form-control" id="email" required>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="name"><b>Téléphone</b></label>
                                            <input type="tel" class="form-control" name="phone" id="phone" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="name"><b>Sujet</b></label>
                                        <input type="text" class="form-control" name="subject" id="subject" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="name"><b>Message</b></label>
                                        <textarea class="form-control" name="message" rows="4" required></textarea>
                                    </div>
                                    <div class="text-center"><button type="submit">Envoyer message</button></div>
                                    <br>
                                </form>

                            </div>

                            <div class="col-lg-5 d-flex align-items-stretch">
                                <div class="info">
                                    <div class="address">
                                        <i class="bi bi-geo-alt"></i>
                                        <h4>MACONSEILLÈRECOM:</h4>
                                        <p>Agence de communication spécialisée en stratégie de la communication , les relations publiques et la gestion de Crises.</p>
                                    </div>

                                    <div class="email">
                                        <i class="bi bi-envelope"></i>
                                        <h4>Email:</h4>
                                        <p>contact@maconseillerecom.com <br>direction@maconseillerecom.com</p>
                                    </div>

                                    <div class="phone">
                                        <i class="bi bi-phone"></i>
                                        <h4>Téléphones :</h4>
                                        <p>
                                        +225 05 86 28 55 00 <br> +226 05 55 50 05
                                        </p>
                                    </div>

                                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>
                                </div>

                            </div>
                        </div>

                    </div>
                </section><!-- End Contact Section -->
            </div>
        </section>

    </main><!-- End #main -->
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projets\maconseillerecom\resources\views/contact/contact.blade.php ENDPATH**/ ?>