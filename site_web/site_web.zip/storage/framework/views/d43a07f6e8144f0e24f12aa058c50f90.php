<?php $__env->startSection('title'); ?>
    Referencement SEO/SEA
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs p-2" style="height: 100px">
        <div class="breadcrumbs breadcrumb-hero">
            <ol>
                <li><a href="/" style="font-size:25px"><b>Home</b></a></li>
                <li style="font-size:25px"><b>Referencement SEO/SEA</b></li>
            </ol>
        </div>
    </section><!-- End Breadcrumbs -->
    <br><br>
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 pt-3 pt-lg-0 content">
                    <p>Nous sommes une agence de référencement naturel en Afrique. Notre but est d’accroître la visibilité de votre site web de manière organique sur les moteurs de recherche autour de vos mots-clés cible.</p>
                    <p>Cela permet d’accroître le nombre de visites sur votre site web ainsi que le nombre de leads qualifiés générés. Ainsi, vous pourrez facilement accroître votre chiffre d’affaires. </p>
                </div>

            </div>
            <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary" style='float:right;background-color:#44b6e3;border: 1px solid ;background-color:#44b6e3;'><b>Contactez-nous</b></a>
        </div>
    </section><!-- End About Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projets\maconseillerecom\resources\views/marketing_digital/referencement_google.blade.php ENDPATH**/ ?>