<?php $__env->startSection('title'); ?>
    Production Multimédia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs p-2" style="height: 100px">
        <div class="breadcrumbs breadcrumb-hero">
            <ol>
                <li><a href="/" style="font-size:25px"><b>Home</b></a></li>
                <li style="font-size:25px"><b>Production audiovisuelle</b></li>
            </ol>
        </div>
    </section><!-- End Breadcrumbs -->
    <br><br>
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 pt-3 pt-lg-0 content">
                    <p>De la Conception à la réalisation des œuvres audiovisuelles et cinématographiques. MaConseillèreCom mets à votre disposition des spécialistes de la production audiovisuelle ainsi que des présentateurs et animateurs professionnels.</p>
                    <ul>
                        <li> La Création de contenus </li>
                        <li> Réalisations capsules vidéos</li>
                        <li> La Production d’émissions de télévision</li>
                    </ul>
                </div>

            </div>
            <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary" style='float:right;background-color:#44b6e3;border: 1px solid ;background-color:#44b6e3;'><b>Contactez-nous</b></a>
        </div>
    </section><!-- End About Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projets\maconseillerecom\resources\views/communication/production-multimedia.blade.php ENDPATH**/ ?>