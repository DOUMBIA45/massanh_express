<a href="" class="navbar- p-0">
    <!--<h1 class="m-0"><i class="fa fa-map-marker-alt me-3"></i>Travela</h1>-->
    <img src="assets/img/logo.jpeg" alt="Logo" style="height: 86px;width: 150px">
</a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
    <span class="fa fa-bars"></span>
</button>
<div class="collapse navbar-collapse" id="navbarCollapse">
    <div class="navbar-nav ms-auto py-0">
        <a href="<?php echo e(route('HomePage')); ?>" class="nav-item nav-link <?php echo e(Route::current()->getName() == 'HomePage' ? 'active':''); ?>"><b>Accueil</b></a>
        <div class="nav-item dropdown">
            <a href="#" class="nav-link dropdown-toggle <?php echo e(Route::current()->getName() == 'listeProduits' ? 'active':''); ?>" data-bs-toggle="dropdown"><b>Produits</b></a>
            <div class="dropdown-menu m-0">
                <a href="<?php echo e(route('listeProduits')); ?>?token=<?php echo e(\Str::random(100)); ?>" class="dropdown-item">Equipements médicaux</a>
                <a href="<?php echo e(route('listeProduits')); ?>?token=<?php echo e(\Str::random(100)); ?>" class="dropdown-item">Gaz et Fluids médicaux</a>
                <a href="<?php echo e(route('listeProduits')); ?>?token=<?php echo e(\Str::random(100)); ?>" class="dropdown-item">Traitement des déchets</a>
            </div>
        </div>
        <a href="<?php echo e(route('actualite')); ?>?token=<?php echo e(\Str::random(100)); ?>" class="nav-item nav-link <?php echo e(Route::current()->getName() == 'actualite' ? 'active':''); ?>"><b>Actualité</b></a>
        <a href="<?php echo e(route('equipe')); ?>?token=<?php echo e(\Str::random(100)); ?>" class="nav-item nav-link <?php echo e(Route::current()->getName() == 'equipe' ? 'active':''); ?>"><b>Equipe</b></a>
        <a href="<?php echo e(route('contact')); ?>?token=<?php echo e(\Str::random(100)); ?>" class="nav-item nav-link <?php echo e(Route::current()->getName() == 'contact' ? 'active':''); ?>"><b>Contact</b></a>
    </div>
</div>
<?php /**PATH E:\projets\WEB\massanh_express\site_web\resources\views/layout/header.blade.php ENDPATH**/ ?>