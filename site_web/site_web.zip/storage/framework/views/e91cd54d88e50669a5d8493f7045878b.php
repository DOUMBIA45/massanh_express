<?php $__env->startSection('title'); ?>
Personal Branding
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs p-2" style="height: 100px">
        <div class="breadcrumbs breadcrumb-hero">
            <ol>
                <li><a href="/" style="font-size:25px"><b>Home</b></a></li>
                <li style="font-size:25px"><b> Personnal branding</b></li>
            </ol>
        </div>
    </section><!-- End Breadcrumbs -->
    <br><br>
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 pt-3 pt-lg-0 content">
                    <h4 style="font-size: 18px"><b>C’est vous la marque! </b> </h4>
                    <p > Votre communication en image est notre priorité.</p>
                    <p> Le personal branding ou encore le marketing personnel permet à notre agence de mettre en lumière la gestion de votre communication en image et votre positionnement.</p>
                    <h4 style="font-size: 18px"><b>Notre objectif : </b> </h4>
                    <p> Vous faire connaitre, faire de vous une valeur ajoutée pour votre entourage, votre public professionnel. Nous avons l’art de maitriser votre image tout le long de votre carrière.</p>
                    <p >Notre stratégie infaillible fera de vous et votre entreprise une identité de marque.</p>
                </div>

            </div>
            <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary" style='float:right;background-color:#44b6e3;border: 1px solid ;background-color:#44b6e3;'><b>Contactez-nous</b></a>
        </div>
    </section><!-- End About Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projets\maconseillerecom\resources\views/communication/personal-branding.blade.php ENDPATH**/ ?>