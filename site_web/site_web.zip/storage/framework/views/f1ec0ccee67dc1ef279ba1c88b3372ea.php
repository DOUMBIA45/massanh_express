<div class="container d-flex align-items-center justify-content-between">

    <div class="logo">
        <h1 class="text-light"><a href="index.html">MaconseillèreCom</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <a href="/"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="" class="img-fluid"></a>
    </div>

    <nav id="navbar" class="navbar">
        <ul>
            <li><a class="<?php echo e(Route::current()->getName()=='HomePage'?'active':''); ?>" href="<?php echo e(route('HomePage')); ?>"><b>Accueil</b></a></li>
            <li class="dropdown"><a href="#"><span><b>Agence conseil</b></span> <i class="bi bi-chevron-down"></i></a>
                <ul>
                    <li><a href="<?php echo e(route('Spin_doctor')); ?>">Spin doctor</a></li>
                    <li><a href="<?php echo e(route('gestion-crises')); ?>">Gestion de crises</a></li>
                    <li><a href="<?php echo e(route('coaching')); ?>">Coaching</a></li>
                </ul>
            </li>
            <li class="dropdown"><a href="#"><span><b>Communication</b></span> <i class="bi bi-chevron-down"></i></a>
                <ul>
                    <li><a href="<?php echo e(route('communicationVisuelle')); ?>">Communication visuelle</a></li>
                    <li><a href="<?php echo e(route('production-multimedia')); ?>">Production audiovisuelle</a></li>
                    <li><a href="<?php echo e(route('personal-branding')); ?>">Personnal branding</a></li>
                    <li><a href="<?php echo e(route('MaketingInfluence')); ?>">Marketing d'influence</a></li>
                </ul>
            </li>
            <li class="dropdown"    ><a href="#"><span><b>Rélations publiques</b></span> <i class="bi bi-chevron-down"></i></a>
                <ul>
                    <li><a href="<?php echo e(route('relations-presses')); ?>">Relations presses</a></li>
                    <li><a href="<?php echo e(route('campagne-publicitaire')); ?>">Campagnes publicitaires</a></li>
                </ul>
            </li>
            <li class="dropdown"    ><a href="#"><span><b>Management</b></span> <i class="bi bi-chevron-down"></i></a>
                <ul>
                    <li><a href="<?php echo e(route('business-management')); ?>">Business Management</a></li>
                    <li><a href="<?php echo e(route('event-management-evenementiel')); ?>">Event Management/Événementiel</a></li>
                </ul>
            </li>
            <li class="dropdown"><a href="#"><span><b>Marketing digital </b></span> <i class="bi bi-chevron-down"></i></a>
                <ul>
                    <li><a href="<?php echo e(route('StrategieDigitale')); ?>">Strategie digitale </a></li>
                    <li><a href="<?php echo e(route('CreationSiteInternet')); ?>">Creation de site internet & applications</a></li>
                    <li><a href="<?php echo e(route('ReferencementGoogle')); ?>">Referencement google</a></li>
                    <li><a href="<?php echo e(route('CommunityManagement')); ?>">Community Management</a></li>
                </ul>
            </li>
            <li><a class="getstarted <?php echo e(Route::current()->getName()=='contact'?'active':''); ?>" href="<?php echo e(route('contact')); ?>" style="color: #000000"><b>Contact</b></a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
    </nav><!-- .navbar -->

</div>
<?php /**PATH E:\projets\maconseillerecom\resources\views/layout/header.blade.php ENDPATH**/ ?>