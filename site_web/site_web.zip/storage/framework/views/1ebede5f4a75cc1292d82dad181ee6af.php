<?php $__env->startSection('title'); ?>
    Event Management et Événementiel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs p-2" style="height: 100px">
        <div class="breadcrumbs breadcrumb-hero">
            <ol>
                <li><a href="/" style="font-size:25px"><b>Home</b></a></li>
                <li style="font-size:25px"><b>Event Management</b></li>
            </ol>
        </div>
    </section><!-- End Breadcrumbs -->
    <br><br>
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 pt-3 pt-lg-0 content">
                    <h4 style="font-size: 18px"><b>Vous êtes uniques !</b> </h4>
                    <ul>
                        <li> De l’imagination à la planification. </li>
                        <li> De la gestion à la réalisation.</li>
                        <li> Nous englobons le processus intégral par la personnalisation de vos évènements de A – Z.</li>
                        <li> Une équipe d’évent planner professionnel et discipliné à votre écoute.</li>
                        <li> La création des concepts et leurs originalités sont la différence qui crée une différence.</li>
                    </ul>
                </div>

            </div>
            <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary" style='float:right;background-color:#44b6e3;border: 1px solid ;background-color:#44b6e3;'><b>Contactez-nous</b></a>
        </div>
    </section><!-- End About Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projets\maconseillerecom\resources\views/management/event-management-evenementiel.blade.php ENDPATH**/ ?>