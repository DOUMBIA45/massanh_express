<div class="container" data-aos="fade-up">
    <div class="section-title">
        <h2>L’ÉQUIPE PARFAITE </h2>
        <p></p>
    </div>

    <div class="row">

        <div class="col-lg-6" data-aos="zoom-in" data-aos-delay="100">
            <div class="member d-flex align-items-start">
                <div class="pic"><img src="assets/img/team/team-1.jpg" class="img-fluid" alt=""></div>
                <div class="member-info">
                    <h4>Des spécialites en communication</h4>
                    <span></span>
                    <p>Une équipe d’experts en relations publiques et gestion de crises de tous  genres  </p>
                    <div class="social">
                        <a href=""><i class="bi bi-twitter"></i></a>
                        <a href=""><i class="bi bi-facebook"></i></a>
                        <a href=""><i class="bi bi-instagram"></i></a>
                        <a href=""> <i class="bi bi-linkedin"></i> </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="member d-flex align-items-start">
                <div class="pic"><img src="assets/img/team/team-3.jpg" class="img-fluid" alt=""></div>
                <div class="member-info">
                    <h4>Une équipe de journalistes chevronnés  </h4>
                    <span></span>
                    <p>Mise  en veille informationnelle 24h/24h tenus par le secret professionnel.</p>
                    <div class="social">
                        <a href=""><i class="bi bi-twitter"></i></a>
                        <a href=""><i class="bi bi-facebook"></i></a>
                        <a href=""><i class="bi bi-instagram"></i></a>
                        <a href=""> <i class="bi bi-linkedin"></i> </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 mt-4" data-aos="zoom-in" data-aos-delay="300">
            <div class="member d-flex align-items-start">
                <div class="pic"><img src="assets/img/team/team-2.jpg" class="img-fluid" alt=""></div>
                <div class="member-info">
                    <h4>Une équipe de développeurs d'application web et mobile </h4>
                    <span></span>
                    <p>Nous concevons pour vous des Site Web et Application sur mesure</p>
                    <div class="social">
                        <a href=""><i class="bi bi-twitter"></i></a>
                        <a href=""><i class="bi bi-facebook"></i></a>
                        <a href=""><i class="bi bi-instagram"></i></a>
                        <a href=""> <i class="bi bi-linkedin"></i> </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 mt-4" data-aos="zoom-in" data-aos-delay="400">
            <div class="member d-flex align-items-start">
                <div class="pic"><img src="assets/img/team/team-4.jpg" class="img-fluid" alt=""></div>
                <div class="member-info">
                    <h4>Une équipe d'avocat de renommée</h4>
                    <span></span>
                    <p>Des avocats de renommée qui travaillent dans la stricte confidentialité .</p>
                    <div class="social">
                        <a href=""><i class="bi bi-twitter"></i></a>
                        <a href=""><i class="bi bi-facebook"></i></a>
                        <a href=""><i class="bi bi-instagram"></i></a>
                        <a href=""> <i class="bi bi-linkedin"></i> </a>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>
<?php /**PATH E:\projets\maconseillerecom\resources\views/layout/home/teams.blade.php ENDPATH**/ ?>