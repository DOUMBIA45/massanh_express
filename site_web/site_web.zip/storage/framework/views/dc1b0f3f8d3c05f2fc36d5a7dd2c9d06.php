<?php $__env->startSection('title'); ?>
    Agence Communication & RP Corporate
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container" data-aos="fade-up">
        <h1 style="font-weight: bolder;font-size: 50px;text-align: center">Agence Communication & RP Corporate</h1>
        <!-- <a href="#" class="btn-get-started scrollto" style="background-color: black">Commencer</a> -->
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="row justify-content-end">
          <div class="col-lg-11">
            <div class="row justify-content-end">

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box py-5">
                  <i class="bi bi-emoji-smile"></i>
                  <span data-purecounter-start="0" data-purecounter-end="65" class="purecounter">0</span>
                  <p>Clients satisfaits</p>
                </div>
              </div>

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box py-5">
                  <i class="bi bi-journal-richtext"></i>
                  <span data-purecounter-start="0" data-purecounter-end="30" class="purecounter">0</span>
                  <p>Projets</p>
                </div>
              </div>

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box pb-5 pt-0 pt-lg-5">
                  <i class="bi bi-clock"></i>
                  <span data-purecounter-start="0" data-purecounter-end="10" class="purecounter">0</span>
                  <p>Nombre d'année d'experience</p>
                </div>
              </div>

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box pb-5 pt-0 pt-lg-5">
                  <i class="bi bi-award"></i>
                  <span data-purecounter-start="0" data-purecounter-end="5" class="purecounter">0</span>
                  <p>Awards</p>
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class="row">

          <div class="col-lg-6 video-box align-self-baseline position-relative">
            <img src="<?php echo e(asset('assets/img/bio.png')); ?>" class="img-fluid" alt="">
          <!--  <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="glightbox play-btn mb-4"></a> -->
          </div>
          <div class="col-lg-6 pt-3 pt-lg-0 content">
            <h1 style="font-weight: bolder;font-size: 50px;text-align: center">Ariane Touré</h1>
              <p class="">
                Ceo-spécialiste en communication de marque , relations publiques & gestion de crises-host tv
              </p>
               <p>
             Ariane Touré  émet pour la toute première fois l’idée de créer l’agence de communication ‘’ MaConseillèreCom ‘’ en 2019.<br> Une agence de stratégie  RP corporate proche des réalités communes .<p>Auparavant Journaliste, productrice et Consultante en communication pour de nombreuses personnalités publiques dans l’ombre.
Cette Spin Doctor efficace  , se consacrera entièrement à la RP corporate  quelques années plus tard.</p>
  <!-- <p>Surnommée ‘’l’Olivia pope ivoirienne ‘’, Ariane Touré est connue pour son expertise en stratégie de positionnement en images et de gestion de crises de tous genres .</p> -->
   <p>C’est accompagné d’une équipe parfaite, équipe outillée en la matière qu’elle fait face aux sollicitations de ses clients dans la plus grande des discrétions . </p>
            <ul>
              <li><i class="bx bx-check-double"></i> Agence conseil</li>
              <li><i class="bx bx-check-double"></i>Communication</li>
              <li><i class="bx bx-check-double"></i> Relations publiques</li>
              <li><i class="bx bx-check-double"></i> Management</li>
              <li><i class="bx bx-check-double"></i> Marketing digital</li>
            </ul>
          </div>

        </div>

      </div>
    </section><!-- End About Section -->

   <!-- ======= Services Section ======= -->
    <section id="services" class="services ">
      <div class="container">

        <div class="section-title pt-5" data-aos="fade-up">
          <h2>Nos Services</h2>
        </div>

        <div class="row">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="icon-box">
                        <div class="icon">

                        </div>
                        <h4 class="title"><a href=""><?php echo e($service->titre); ?></a></h4>
                        <p class="description"><?php echo e($service->descriptions); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

      </div>
    </section><!-- End Services Section -->

      <!-- ======= Cta Section ======= -->
  <!--
      <section id="cta" class="cta">
          <div class="container" data-aos="fade-in">

              <div class="text-center">
                  <h3>Call To Action</h3>
                  <p> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                  <a class="cta-btn" href="#">Call To Action</a>
              </div>

          </div>
      </section><-- End Cta Section ----->
      <section id="portfolio" class="portfolio">
          <div class="container">
              <div class="section-title" data-aos="fade-up">
                  <h2>Quelques réalisations</h2>
              </div>
              <div class="row">
                  <div class="col-lg-12 d-flex justify-content-center" data-aos="fade-up">
                      <ul id="portfolio-flters">
                          <li data-filter="*" class="filter-active">Tous</li>
                          <li data-filter=".filter-app">Agence conseil</li>
                          <li data-filter=".filter-web">Communication</li>
                          <li data-filter=".filter-card">Relations publiques</li>
                          <li data-filter=".filter-app">Management</li>
                          <li data-filter=".filter-web">Marketing digital</li>

                      </ul>
                  </div>
              </div>

              <div class="row portfolio-container" data-aos="fade-up">
                  <div class="col-lg-3 col-md-6 portfolio-item filter-app">
                      <div class="portfolio-wrap">
                          <img src="assets/img/portfolio/portfolio-1.jpg" class="img-fluid" alt="">
                          <div class="portfolio-info">
                              <h4>App 1</h4>
                              <p>App</p>
                              <div class="portfolio-links">
                                  <a href="assets/img/portfolio/portfolio-1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 1"><i class="bx bx-plus"></i></a>
                                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                              </div>
                          </div>
                      </div>
                  </div>

                  <div class="col-lg-3 col-md-6 portfolio-item filter-web">
                      <div class="portfolio-wrap">
                          <img src="assets/img/portfolio/portfolio-2.jpg" class="img-fluid" alt="">
                          <div class="portfolio-info">
                              <h4>Web 3</h4>
                              <p>Web</p>
                              <div class="portfolio-links">
                                  <a href="assets/img/portfolio/portfolio-2.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 3"><i class="bx bx-plus"></i></a>
                                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                              </div>
                          </div>
                      </div>
                  </div>

                  <div class="col-lg-3 col-md-6 portfolio-item filter-app">
                      <div class="portfolio-wrap">
                          <img src="assets/img/portfolio/portfolio-3.jpg" class="img-fluid" alt="">
                          <div class="portfolio-info">
                              <h4>App 2</h4>
                              <p>App</p>
                              <div class="portfolio-links">
                                  <a href="assets/img/portfolio/portfolio-3.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 2"><i class="bx bx-plus"></i></a>
                                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                              </div>
                          </div>
                      </div>
                  </div>

                  <div class="col-lg-3 col-md-6 portfolio-item filter-card">
                      <div class="portfolio-wrap">
                          <img src="assets/img/portfolio/portfolio-4.jpg" class="img-fluid" alt="">
                          <div class="portfolio-info">
                              <h4>Card 2</h4>
                              <p>Card</p>
                              <div class="portfolio-links">
                                  <a href="assets/img/portfolio/portfolio-4.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 2"><i class="bx bx-plus"></i></a>
                                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                              </div>
                          </div>
                      </div>
                  </div>

                  <div class="col-lg-3 col-md-6 portfolio-item filter-web">
                      <div class="portfolio-wrap">
                          <img src="assets/img/portfolio/portfolio-5.jpg" class="img-fluid" alt="">
                          <div class="portfolio-info">
                              <h4>Web 2</h4>
                              <p>Web</p>
                              <div class="portfolio-links">
                                  <a href="assets/img/portfolio/portfolio-5.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 2"><i class="bx bx-plus"></i></a>
                                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                              </div>
                          </div>
                      </div>
                  </div>

                  <div class="col-lg-3 col-md-6 portfolio-item filter-app">
                      <div class="portfolio-wrap">
                          <img src="assets/img/portfolio/portfolio-6.jpg" class="img-fluid" alt="">
                          <div class="portfolio-info">
                              <h4>App 3</h4>
                              <p>App</p>
                              <div class="portfolio-links">
                                  <a href="assets/img/portfolio/portfolio-6.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 3"><i class="bx bx-plus"></i></a>
                                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                              </div>
                          </div>
                      </div>
                  </div>

                  <div class="col-lg-3 col-md-6 portfolio-item filter-card">
                      <div class="portfolio-wrap">
                          <img src="assets/img/portfolio/portfolio-7.jpg" class="img-fluid" alt="">
                          <div class="portfolio-info">
                              <h4>Card 1</h4>
                              <p>Card</p>
                              <div class="portfolio-links">
                                  <a href="assets/img/portfolio/portfolio-7.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 1"><i class="bx bx-plus"></i></a>
                                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                              </div>
                          </div>
                      </div>
                  </div>

                  <div class="col-lg-3 col-md-6 portfolio-item filter-card">
                      <div class="portfolio-wrap">
                          <img src="assets/img/portfolio/portfolio-8.jpg" class="img-fluid" alt="">
                          <div class="portfolio-info">
                              <h4>Card 3</h4>
                              <p>Card</p>
                              <div class="portfolio-links">
                                  <a href="assets/img/portfolio/portfolio-8.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 3"><i class="bx bx-plus"></i></a>
                                  <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>

          </div>
      </section><!-- End Portfolio Section -->

      <section id="team" class="team section-bg">
          <div class="container" data-aos="fade-up">

              <div class="section-title">
                  <h2>L’ÉQUIPE PARFAITE </h2>
                  <p></p>
              </div>

              <div class="row">
                  <?php $__currentLoopData = $equipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-lg-6 p-2" data-aos="zoom-in" data-aos-delay="100">
                          <div class="member d-flex align-items-start">
                              <div class="pic"><img src="<?php echo e(asset('assets/img/team/'.$equipe->photo)); ?>" class="img-fluid" alt=""></div>
                              <div class="member-info">
                                  <h4><?php echo e($equipe->titre); ?></h4>
                                  <span></span>
                                  <p><?php echo e($equipe->description); ?></p>
                                  <div class="social">
                                      <a target="_blank" href="<?php echo e($equipe->lien_twitter); ?>"><i class="bi bi-twitter"></i></a>
                                      <a target="_blank" href="<?php echo e($equipe->lien_face); ?>"><i class="bi bi-facebook"></i></a>
                                      <a target="_blank" href="<?php echo e($equipe->lien_insta); ?>"><i class="bi bi-instagram"></i></a>
                                      <a target="_blank" href="<?php echo e($equipe->lien_link); ?>"> <i class="bi bi-linkedin"></i> </a>
                                  </div>
                              </div>
                          </div>
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

          </div>
      </section><!-- End Team Section -->

      <!-- ======= Our Clients Section ======= -->
      <section id="clients" class="clients">
          <div class="container" data-aos="fade-up">

              <div class="section-title">
                  <h2>Ils nous font confiance</h2>
                  <p> </p>
              </div>

              <div class="clients-slider swiper">
                  <div class="swiper-wrapper align-items-center">
                      <?php $__currentLoopData = $partenaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partenaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="swiper-slide"><img src="<?php echo e(asset('assets/img/clients/'.$partenaire->logo)); ?>" class="img-fluid" alt=""></div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <div class="swiper-pagination"></div>
              </div>

          </div>
      </section><!-- End Our Clients Section -->


  </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projets\maconseillerecom\resources\views/welcome.blade.php ENDPATH**/ ?>