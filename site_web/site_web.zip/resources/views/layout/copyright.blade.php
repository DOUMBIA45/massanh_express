
<div class="row">
    <div class="col-md-3 text-center"></div>
    <div class="col-md-6 text-center">
         <a href="/">MASSANANH EXPERTIZ</a>&copy; all Right Reserved.
    </div>
    <div class="col-md-3 text-center"></div>
</div>
